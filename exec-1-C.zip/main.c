
#include<stdio.h>
#include<stdlib.h>
 
int main(){
int turmaA;
int turmaB;
int i = 0;
double mediaA = 0.0;
double mediaB = 0.0;
double somaA = 0.0;
double somaB = 0.0;
double nota = 0.0;
double *lista_de_notas; // Ponteiro
 
printf("Digite a quantidade de alunos da turma A: ");
scanf("%d",&turmaA);
 
// Alocar na memória o vetor com o tamanho da turma
 lista_de_notas = (double*) malloc(turmaA * sizeof(double));

for(i =0; i < turmaA; i++){
        printf("Digite a nota do aluno %d: ",(i+1));
        scanf("%lf",&nota);
        lista_de_notas[i] = nota;
 }
// Calcula a média da turma A
for(i =0; i < turmaA; i++){
        somaA += lista_de_notas[i];
 }
 
 mediaA = somaA / turmaA;

printf("Media da Turma A: %.2f \n",mediaA);
 
printf("Digite a quantidade de alunos da turma B: ");
scanf("%d",&turmaB);
 
// Realoca o tamanho do vetor lista_de_notas de acordo com o tamanho da turma B
lista_de_notas = (double*) realloc(lista_de_notas, turmaB * sizeof(double));
for(i =0; i < turmaB; i++){
        printf("Digite a nota do aluno %d: ",(i+1));
        scanf("%lf",&nota);
        lista_de_notas[i] = nota;
 }
// Calcula a média da turma b
for(i =0; i < turmaB; i++){
         somaB += lista_de_notas[i];
 }
 mediaB = somaB / turmaB;
 

printf("Media da Turma B: %.2f \n",mediaB);
 
// liberar o espaço na memória
free(lista_de_notas);
 
return 0;
}
