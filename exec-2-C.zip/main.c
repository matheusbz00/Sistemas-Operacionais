#include<stdio.h>
#include<stdlib.h>
 
int main(){
 int quantidade = 0;
 int i = 0;
 FILE *arquivo = fopen("produtos.txt","w");
 int codigo[4];
 char nome[101];
 float valor[100];
 
 printf("Quantos produtos serão cadastrados? ");
 scanf("%d",&quantidade);

 for(i = 0; i < quantidade; i++){
        printf("Digite o codigo do produto (3 digitos): ");
        scanf("%d",&codigo[i]);
        printf("Digite o nome do produto (Ate 100 caracteres): ");
        scanf("%s",nome);
        printf("Digite o valor do produto: ");
        scanf("%f",&valor[i]);
 printf("%i %s %f\n",codigo[i],nome,valor[i]);
 fprintf(arquivo,"%i %s %f\n",codigo[i],nome,valor[i]);
 }

 
 if(arquivo != NULL){
        fclose(arquivo);
 }
 
 return 0;
}