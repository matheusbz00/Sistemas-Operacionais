#include<stdio.h>
#include<stdlib.h>
 
int main(){
 int quantidade = 0;
 int i = 0;
 FILE *arquivo = fopen("produtos.txt","r");
 int codigo;
 char nome[101];
 float valor;
 
 if(arquivo != NULL){
 
        while(feof(arquivo) == 0){
        fscanf(arquivo,"%i %s %f\n",&codigo,nome,&valor);
        printf("%i %s %f\n",codigo,nome,valor);
 }
 
 if(arquivo != NULL){
        fclose(arquivo);
 }
 }
 
 return 0;
}